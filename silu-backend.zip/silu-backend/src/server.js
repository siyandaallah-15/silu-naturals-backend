// src/server.js — SiLu Naturals Production Backend
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

import authRoutes        from './routes/auth.js';
import distributorRoutes from './routes/distributor.js';
import adminRoutes       from './routes/admin.js';
import orderRoutes       from './routes/orders.js';

const app  = express();
const PORT = process.env.PORT || 3001;

// ── SECURITY ──────────────────────────────────────────────────
app.use(helmet());
app.set('trust proxy', 1);

app.use(cors({
  origin:      process.env.ALLOWED_ORIGIN || '*',
  credentials: true,
  methods:     ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Rate limiting — stricter on auth routes
const globalLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 300, message: { error: 'Too many requests. Please slow down.' } });
const authLimit   = rateLimit({ windowMs: 15 * 60 * 1000, max: 20,  message: { error: 'Too many login attempts. Try again in 15 minutes.' } });

app.use(globalLimit);
app.use(express.json({ limit: '2mb' }));

// ── HEALTH CHECK ──────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'SiLu Naturals API', time: new Date().toISOString() }));

// ── ROUTES ────────────────────────────────────────────────────
app.use('/api/auth',        authLimit, authRoutes);
app.use('/api/distributor', distributorRoutes);
app.use('/api/admin',       adminRoutes);
app.use('/api/orders',      orderRoutes);

// ── 404 ───────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` }));

// ── ERROR HANDLER ─────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── START ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🌿 SiLu Naturals API running on port ${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Health:      http://localhost:${PORT}/health\n`);
});

export default app;
