// src/routes/orders.js
import { Router } from 'express';
import { z } from 'zod';
import prisma from '../lib/prisma.js';
import { makeOrderNumber, PRODUCT_PRICE, PAXI_SHIPPING } from '../lib/business.js';

const router = Router();

const OrderSchema = z.object({
  product:       z.enum(['HairGrowthOil', 'HairGrowthSerum']),
  quantity:      z.number().int().min(1).max(10),
  customerName:  z.string().min(2),
  customerPhone: z.string().min(9),
  customerEmail: z.string().email(),
  pepStoreNumber:z.string().min(2),
  referralCode:  z.string().optional(),
  paymentMethod: z.string().optional(),
});

// Place an order (public endpoint — no auth needed)
router.post('/', async (req, res) => {
  try {
    const data = OrderSchema.parse(req.body);

    // Validate referral code if given
    if (data.referralCode) {
      const ref = await prisma.distributor.findUnique({ where: { code: data.referralCode } });
      if (!ref) return res.status(400).json({ error: 'Referral code not found.' });
    }

    const subtotal    = data.quantity * PRODUCT_PRICE;
    const total       = subtotal + PAXI_SHIPPING;
    const orderNumber = makeOrderNumber();
    const paymentRef  = `${data.customerName} | ${data.customerPhone} | PEP: ${data.pepStoreNumber} | ${orderNumber}`;

    const order = await prisma.order.create({
      data: {
        orderNumber,
        product:        data.product,
        quantity:       data.quantity,
        unitPrice:      PRODUCT_PRICE,
        shipping:       PAXI_SHIPPING,
        subtotal,
        total,
        customerName:   data.customerName,
        customerPhone:  data.customerPhone,
        customerEmail:  data.customerEmail,
        pepStoreNumber: data.pepStoreNumber,
        referralCode:   data.referralCode || null,
        paymentRef,
        paymentMethod:  data.paymentMethod || null,
        status:         'pending',
      },
    });

    return res.status(201).json({
      order,
      bankingDetails: {
        bankName:      'Capitec Bank',
        accountName:   'Silu Naturals (Pty) Ltd',
        accountNumber: '1055143564',
        accountType:   'Transactional',
        branchCode:    '470010',
        reference:     paymentRef,
      },
      summary: {
        subtotal,
        shipping: PAXI_SHIPPING,
        total,
        orderNumber,
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors[0].message });
    console.error(err);
    return res.status(500).json({ error: 'Failed to place order. Please try again.' });
  }
});

// Get order status (by order number — public, for customer tracking)
router.get('/:orderNumber', async (req, res) => {
  try {
    const order = await prisma.order.findUnique({
      where: { orderNumber: req.params.orderNumber },
      select: {
        orderNumber: true, product: true, quantity: true,
        total: true, status: true, createdAt: true,
        customerName: true, pepStoreNumber: true,
      },
    });
    if (!order) return res.status(404).json({ error: 'Order not found.' });
    return res.json({ order });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to find order.' });
  }
});

export default router;
