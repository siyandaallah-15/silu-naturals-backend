// src/routes/distributor.js
import { Router } from 'express';
import { z } from 'zod';
import prisma from '../lib/prisma.js';
import { requireDistributor } from '../middleware/auth.js';
import {
  getRankByRecruits,
  getMaintenanceStatus,
  calculateUplineCommissions,
  makePaymentRef,
  PRODUCT_PRICE,
  PRODUCT_COST,
  MAINTENANCE_CYCLE_DAYS,
} from '../lib/business.js';

const router = Router();
router.use(requireDistributor);

// ── GET PROFILE / OVERVIEW ────────────────────────────────────
router.get('/me', async (req, res) => {
  try {
    const dist = await prisma.distributor.findUnique({
      where: { code: req.distributor.code },
      include: {
        _count: { select: { recruits: true, sales: true } },
        maintenancePayments: { where: { status: 'confirmed' }, orderBy: { confirmedAt: 'asc' } },
        payouts: { where: { status: { in: ['pending', 'approved'] } } },
        commissions: {
          where: { status: { in: ['pending', 'confirmed'] } },
          select: { commissionAmount: true, status: true },
        },
      },
    });

    const rank         = getRankByRecruits(dist._count.recruits);
    const maintStatus  = getMaintenanceStatus(dist, dist.maintenancePayments, dist.statusOverride);
    const totalEarned  = await prisma.commission.aggregate({
      where: { earnedByCode: dist.code, status: { in: ['confirmed', 'paid'] } },
      _sum:  { commissionAmount: true },
    });
    const pendingBal   = dist.commissions
      .filter(c => c.status === 'pending' || c.status === 'confirmed')
      .reduce((a, c) => a + c.commissionAmount, 0);

    return res.json({
      distributor: safeDistributor(dist),
      rank,
      maintStatus: {
        ...maintStatus,
        nextDueDate:  maintStatus.nextDueDate?.toISOString(),
        lastPaidDate: maintStatus.lastPaidDate?.toISOString(),
      },
      stats: {
        totalEarned:  totalEarned._sum.commissionAmount || 0,
        availableBalance: pendingBal,
        unitsSold:    dist._count.sales,
        teamSize:     dist._count.recruits,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to load profile.' });
  }
});

// ── SALES ─────────────────────────────────────────────────────
router.get('/sales', async (req, res) => {
  try {
    const sales = await prisma.sale.findMany({
      where:   { distributorCode: req.distributor.code },
      orderBy: { date: 'desc' },
      take:    100,
    });
    return res.json({ sales });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load sales.' });
  }
});

const SaleSchema = z.object({
  product:      z.enum(['HairGrowthOil', 'HairGrowthSerum']),
  quantity:     z.number().int().min(1).max(100),
  customerName: z.string().optional(),
});

router.post('/sales', async (req, res) => {
  try {
    const data   = SaleSchema.parse(req.body);
    const code   = req.distributor.code;
    const revenue = data.quantity * PRODUCT_PRICE;
    const profit  = data.quantity * PRODUCT_COST;

    // Check maintenance status — suspended distributors can still log sales but no commission flows
    const dist = await prisma.distributor.findUnique({
      where: { code },
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { where: { status: 'confirmed' } },
      },
    });
    const maintStatus = getMaintenanceStatus(dist, dist.maintenancePayments, dist.statusOverride);

    const sale = await prisma.sale.create({
      data: {
        distributorCode: code,
        product:         data.product,
        quantity:        data.quantity,
        unitPrice:       PRODUCT_PRICE,
        costPrice:       PRODUCT_COST,
        revenue,
        profit,
        customerName:    data.customerName || null,
        status:          'pending',
      },
    });

    // Propagate commissions up the sponsor chain (only if this dist is active)
    if (maintStatus.status !== 'suspended') {
      await propagateCommissions(code, sale.id, revenue);
    }

    await prisma.activityLog.create({
      data: { actorType: 'distributor', actorId: code, action: 'sale_logged', details: { saleId: sale.id, product: data.product, quantity: data.quantity } },
    });

    return res.status(201).json({ sale, commissionsPropagated: maintStatus.status !== 'suspended' });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors[0].message });
    console.error(err);
    return res.status(500).json({ error: 'Failed to log sale.' });
  }
});

// ── COMMISSIONS ───────────────────────────────────────────────
router.get('/commissions', async (req, res) => {
  try {
    const [commissions, thisMonth, allTime] = await Promise.all([
      prisma.commission.findMany({
        where:   { earnedByCode: req.distributor.code },
        orderBy: { date: 'desc' },
        take:    200,
      }),
      prisma.commission.aggregate({
        where: {
          earnedByCode: req.distributor.code,
          date: { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
          status: { in: ['confirmed', 'paid'] },
        },
        _sum: { commissionAmount: true },
      }),
      prisma.commission.aggregate({
        where:  { earnedByCode: req.distributor.code, status: { in: ['confirmed', 'paid'] } },
        _sum:   { commissionAmount: true },
      }),
    ]);

    return res.json({
      commissions,
      thisMonth: thisMonth._sum.commissionAmount || 0,
      allTime:   allTime._sum.commissionAmount   || 0,
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load commissions.' });
  }
});

// ── TEAM ──────────────────────────────────────────────────────
router.get('/team', async (req, res) => {
  try {
    const code  = req.distributor.code;
    const level1 = await getTeamLevel(code, 1);
    const level2 = (await Promise.all(level1.map(d => getTeamLevel(d.code, 2)))).flat();
    const level3 = (await Promise.all(level2.map(d => getTeamLevel(d.code, 3)))).flat();
    const level4 = (await Promise.all(level3.map(d => getTeamLevel(d.code, 4)))).flat();

    return res.json({
      l1: level1, l2: level2, l3: level3, l4: level4,
      counts: { l1: level1.length, l2: level2.length, l3: level3.length, l4: level4.length, total: level1.length + level2.length + level3.length + level4.length },
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load team.' });
  }
});

async function getTeamLevel(sponsorCode) {
  return prisma.distributor.findMany({
    where: { sponsorCode },
    select: { code: true, fname: true, lname: true, rankName: true, joinDate: true, _count: { select: { sales: true } } },
  });
}

// ── PAYOUT REQUEST ────────────────────────────────────────────
const PayoutSchema = z.object({
  amount:        z.number().int().min(100),
  bankName:      z.string().min(2),
  accountNumber: z.string().min(5),
  accountType:   z.string(),
  branchCode:    z.string().optional(),
});

router.post('/payout', async (req, res) => {
  try {
    const data = PayoutSchema.parse(req.body);

    // Check available balance
    const available = await prisma.commission.aggregate({
      where: { earnedByCode: req.distributor.code, status: 'confirmed' },
      _sum:  { commissionAmount: true },
    });
    const balance = available._sum.commissionAmount || 0;
    if (data.amount > balance) {
      return res.status(400).json({ error: `Requested amount exceeds available balance of R${balance}.` });
    }

    const payout = await prisma.payoutRequest.create({
      data: {
        distributorCode: req.distributor.code,
        amount:          data.amount,
        bankName:        data.bankName,
        accountNumber:   data.accountNumber,
        accountType:     data.accountType,
        branchCode:      data.branchCode || null,
      },
    });

    await prisma.activityLog.create({
      data: { actorType: 'distributor', actorId: req.distributor.code, action: 'payout_requested', details: { amount: data.amount } },
    });

    return res.status(201).json({ payout, message: 'Payout request submitted. Processing within 3–5 business days after admin approval.' });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors[0].message });
    return res.status(500).json({ error: 'Failed to submit payout request.' });
  }
});

router.get('/payouts', async (req, res) => {
  const payouts = await prisma.payoutRequest.findMany({
    where:   { distributorCode: req.distributor.code },
    orderBy: { requestedAt: 'desc' },
  });
  return res.json({ payouts });
});

// ── MAINTENANCE ───────────────────────────────────────────────
router.get('/maintenance', async (req, res) => {
  try {
    const dist = await prisma.distributor.findUnique({
      where: { code: req.distributor.code },
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { orderBy: { submittedAt: 'desc' } },
      },
    });
    const confirmedPayments = dist.maintenancePayments.filter(p => p.status === 'confirmed');
    const status = getMaintenanceStatus(dist, confirmedPayments, dist.statusOverride);

    return res.json({
      status: {
        ...status,
        nextDueDate:  status.nextDueDate?.toISOString(),
        lastPaidDate: status.lastPaidDate?.toISOString(),
      },
      payments: dist.maintenancePayments,
      bankingDetails: {
        bankName:       'Capitec Bank',
        accountName:    'Silu Naturals (Pty) Ltd',
        accountNumber:  '1055143564',
        accountType:    'Transactional',
        branchCode:     '470010',
        reference:      makePaymentRef(`${dist.fname} ${dist.lname}`, dist.phone, 'MAINT', dist.code),
      },
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load maintenance data.' });
  }
});

// Submit proof of maintenance payment
router.post('/maintenance/submit', async (req, res) => {
  try {
    const { reference, method } = req.body;
    const dist = await prisma.distributor.findUnique({
      where: { code: req.distributor.code },
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { where: { status: 'confirmed' } },
      },
    });
    const status = getMaintenanceStatus(dist, dist.maintenancePayments, dist.statusOverride);
    const periodStart = status.lastPaidDate;
    const periodEnd   = status.nextDueDate;

    const payment = await prisma.maintenancePayment.create({
      data: {
        distributorCode: dist.code,
        amount:          status.fee,
        periodStart,
        periodEnd,
        method:          method || 'EFT',
        reference:       reference || null,
        status:          'pending',
      },
    });

    await prisma.activityLog.create({
      data: { actorType: 'distributor', actorId: dist.code, action: 'maintenance_submitted', details: { amount: status.fee } },
    });

    return res.status(201).json({ payment, message: 'Payment notification submitted. Admin will confirm within 24 hours.' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to submit maintenance payment.' });
  }
});

// ── REFERRAL LINK ─────────────────────────────────────────────
router.get('/referral-link', async (req, res) => {
  const baseUrl = process.env.FRONTEND_URL || 'https://silunaturals.co.za';
  return res.json({ link: `${baseUrl}?ref=${req.distributor.code}`, code: req.distributor.code });
});

// ── HELPERS ───────────────────────────────────────────────────
async function propagateCommissions(sellerCode, saleId, saleAmount) {
  // Walk up 4 levels of upline
  const ancestors = [];
  let currentCode = sellerCode;
  for (let level = 0; level < 4; level++) {
    const dist = await prisma.distributor.findFirst({
      where: { recruits: { some: { code: currentCode } } },
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { where: { status: 'confirmed' } },
      },
    });
    if (!dist) break;
    ancestors.push(dist);
    currentCode = dist.code;
  }
  const events = calculateUplineCommissions(sellerCode, ancestors, saleAmount, saleId);
  if (events.length > 0) {
    await prisma.commission.createMany({ data: events });
  }
}

function safeDistributor(d) {
  const { passwordHash, idNumber, ...safe } = d;
  return safe;
}

export default router;
