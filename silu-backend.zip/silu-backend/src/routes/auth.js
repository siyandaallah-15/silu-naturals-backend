// src/routes/auth.js
import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import prisma from '../lib/prisma.js';
import { generateDistributorCode, PACK_PRICES } from '../lib/business.js';

const router = Router();

// ── DISTRIBUTOR REGISTER ──────────────────────────────────────
const RegisterSchema = z.object({
  fname:     z.string().min(1).max(50),
  lname:     z.string().min(1).max(50),
  email:     z.string().email(),
  phone:     z.string().min(9).max(15),
  idNumber:  z.string().length(13).regex(/^\d+$/, 'ID must be 13 digits'),
  city:      z.string().min(1).max(100),
  pack:      z.enum(['Silver', 'Gold', 'Platinum']),
  password:  z.string().min(8),
  referralCode: z.string().optional(),
});

router.post('/register', async (req, res) => {
  try {
    const data = RegisterSchema.parse(req.body);

    // Check email not already taken
    const exists = await prisma.distributor.findUnique({ where: { email: data.email } });
    if (exists) return res.status(409).json({ error: 'An account with this email already exists.' });

    // Validate referral code if provided
    if (data.referralCode) {
      const sponsor = await prisma.distributor.findUnique({ where: { code: data.referralCode } });
      if (!sponsor) return res.status(400).json({ error: 'Referral code not found. Please check and try again.' });
    }

    // Generate unique code
    const allCodes = await prisma.distributor.findMany({ select: { code: true } });
    const existingCodes = new Set(allCodes.map(d => d.code));
    const code = generateDistributorCode(data.fname, existingCodes);

    const passwordHash = await bcrypt.hash(data.password, 12);

    const distributor = await prisma.distributor.create({
      data: {
        code,
        fname:       data.fname,
        lname:       data.lname,
        email:       data.email,
        phone:       data.phone,
        idNumber:    data.idNumber,
        city:        data.city,
        pack:        data.pack,
        passwordHash,
        sponsorCode: data.referralCode || null,
      },
    });

    // Log activity
    await prisma.activityLog.create({
      data: { actorType: 'distributor', actorId: distributor.code, action: 'register', details: { pack: data.pack } },
    });

    const token = signDistributorToken(distributor);
    const packPrice = PACK_PRICES[data.pack];

    return res.status(201).json({
      message: `Welcome to SiLu Naturals, ${data.fname}! Your distributor code is ${code}.`,
      token,
      distributor: safeDistributor(distributor),
      registrationPayment: {
        amount: packPrice,
        pack:   data.pack,
        bankName:      'Capitec Bank',
        accountName:   'Silu Naturals (Pty) Ltd',
        accountNumber: '1055143564',
        accountType:   'Transactional',
        branchCode:    '470010',
        reference:     `${data.fname} ${data.lname} | ${data.phone} | REG: ${data.pack} | ${code}`,
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors[0].message });
    console.error('Register error:', err);
    return res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// ── DISTRIBUTOR LOGIN ─────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

    const dist = await prisma.distributor.findUnique({
      where: { email },
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { where: { status: 'confirmed' }, orderBy: { confirmedAt: 'asc' } },
      },
    });
    if (!dist) return res.status(401).json({ error: 'Invalid email or password.' });

    const valid = await bcrypt.compare(password, dist.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password.' });

    await prisma.activityLog.create({
      data: { actorType: 'distributor', actorId: dist.code, action: 'login', ip: req.ip },
    });

    const token = signDistributorToken(dist);
    return res.json({ token, distributor: safeDistributor(dist) });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ── ADMIN LOGIN ───────────────────────────────────────────────
router.post('/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password are required.' });

    const admin = await prisma.adminUser.findUnique({ where: { username } });
    if (!admin) return res.status(401).json({ error: 'Invalid credentials.' });

    const valid = await bcrypt.compare(password, admin.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials.' });

    await prisma.adminUser.update({ where: { id: admin.id }, data: { lastLogin: new Date() } });
    await prisma.activityLog.create({
      data: { actorType: 'admin', actorId: admin.id, action: 'admin_login', ip: req.ip },
    });

    const token = jwt.sign(
      { type: 'admin', id: admin.id, role: admin.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    return res.json({ token, admin: { id: admin.id, username: admin.username, role: admin.role } });
  } catch (err) {
    console.error('Admin login error:', err);
    return res.status(500).json({ error: 'Login failed.' });
  }
});

// ── HELPERS ───────────────────────────────────────────────────
function signDistributorToken(dist) {
  return jwt.sign(
    { type: 'distributor', code: dist.code, id: dist.id },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

function safeDistributor(d) {
  const { passwordHash, idNumber, ...safe } = d;
  return safe;
}

export default router;
