// src/routes/admin.js
import { Router } from 'express';
import { z } from 'zod';
import prisma from '../lib/prisma.js';
import { requireAdmin, requireOwner } from '../middleware/auth.js';
import { getRankByRecruits, getMaintenanceStatus, GRACE_PERIOD_DAYS } from '../lib/business.js';

const router = Router();
router.use(requireAdmin);

// ── DISTRIBUTORS ──────────────────────────────────────────────
router.get('/distributors', async (req, res) => {
  try {
    const dists = await prisma.distributor.findMany({
      include: {
        _count: { select: { recruits: true, sales: true } },
        maintenancePayments: { where: { status: 'confirmed' }, orderBy: { confirmedAt: 'asc' } },
      },
      orderBy: { joinDate: 'desc' },
    });

    const result = dists.map(d => {
      const rank = getRankByRecruits(d._count.recruits);
      const maint = getMaintenanceStatus(d, d.maintenancePayments, d.statusOverride);
      return {
        ...safeDistributor(d),
        rank: rank.name,
        recruits: d._count.recruits,
        sales:    d._count.sales,
        maintStatus: {
          status:       maint.status,
          daysOverdue:  maint.daysOverdue,
          nextDueDate:  maint.nextDueDate?.toISOString(),
          fee:          maint.fee,
          canBeSuspended: maint.canBeSuspended,
        },
      };
    });

    // Also auto-suspend anyone past grace period
    const toSuspend = dists.filter(d => {
      const m = getMaintenanceStatus(d, d.maintenancePayments, d.statusOverride);
      return m.status === 'suspended' && !d.statusOverride;
    });
    if (toSuspend.length > 0) {
      await prisma.distributor.updateMany({
        where: { id: { in: toSuspend.map(d => d.id) } },
        data:  { statusOverride: 'suspended' },
      });
    }

    return res.json({ distributors: result, total: result.length });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to load distributors.' });
  }
});

// Suspend a distributor
router.post('/distributors/:code/suspend', async (req, res) => {
  try {
    const dist = await prisma.distributor.findUnique({
      where: { code: req.params.code },
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { where: { status: 'confirmed' } },
      },
    });
    if (!dist) return res.status(404).json({ error: 'Distributor not found.' });

    const maint = getMaintenanceStatus(dist, dist.maintenancePayments, dist.statusOverride);

    // Enforce grace period — only owner can override
    if (maint.status === 'grace' && req.admin.role !== 'owner') {
      return res.status(403).json({
        error: `This distributor is still in their ${GRACE_PERIOD_DAYS}-day grace period (${GRACE_PERIOD_DAYS - maint.daysOverdue} days remaining). Only the account owner can suspend during grace period.`,
        graceDaysRemaining: GRACE_PERIOD_DAYS - maint.daysOverdue,
      });
    }

    await prisma.distributor.update({
      where: { code: req.params.code },
      data:  { statusOverride: 'suspended' },
    });

    await prisma.activityLog.create({
      data: { actorType: 'admin', actorId: req.admin.id, action: 'dist_suspended', details: { distCode: req.params.code, adminRole: req.admin.role } },
    });

    return res.json({ message: `Account suspended: ${dist.fname} ${dist.lname}` });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to suspend account.' });
  }
});

// Activate a distributor
router.post('/distributors/:code/activate', async (req, res) => {
  try {
    const dist = await prisma.distributor.findUnique({ where: { code: req.params.code } });
    if (!dist) return res.status(404).json({ error: 'Distributor not found.' });

    await prisma.distributor.update({
      where: { code: req.params.code },
      data:  { statusOverride: 'active' },
    });

    await prisma.activityLog.create({
      data: { actorType: 'admin', actorId: req.admin.id, action: 'dist_activated', details: { distCode: req.params.code } },
    });

    return res.json({ message: `Account activated: ${dist.fname} ${dist.lname}` });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to activate account.' });
  }
});

// ── MAINTENANCE MANAGEMENT ────────────────────────────────────
router.get('/maintenance', async (req, res) => {
  try {
    const dists = await prisma.distributor.findMany({
      include: {
        _count: { select: { recruits: true } },
        maintenancePayments: { orderBy: { submittedAt: 'desc' } },
      },
    });

    let activeCount = 0, graceCount = 0, suspendedCount = 0;
    const result = dists.map(d => {
      const confirmedPayments = d.maintenancePayments.filter(p => p.status === 'confirmed');
      const maint = getMaintenanceStatus(d, confirmedPayments, d.statusOverride);
      if (maint.status === 'active')     activeCount++;
      else if (maint.status === 'grace') graceCount++;
      else                               suspendedCount++;
      const pending = d.maintenancePayments.filter(p => p.status === 'pending');
      return {
        ...safeDistributor(d),
        rank: getRankByRecruits(d._count.recruits).name,
        maint: {
          ...maint,
          nextDueDate:  maint.nextDueDate?.toISOString(),
          lastPaidDate: maint.lastPaidDate?.toISOString(),
        },
        pendingPayments: pending,
        allPayments:     d.maintenancePayments,
      };
    });

    return res.json({ distributors: result, counts: { active: activeCount, grace: graceCount, suspended: suspendedCount } });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load maintenance data.' });
  }
});

// Confirm a maintenance payment
router.post('/maintenance/:paymentId/confirm', async (req, res) => {
  try {
    const payment = await prisma.maintenancePayment.findUnique({ where: { id: req.params.paymentId } });
    if (!payment) return res.status(404).json({ error: 'Payment not found.' });
    if (payment.status === 'confirmed') return res.status(400).json({ error: 'Already confirmed.' });

    await prisma.maintenancePayment.update({
      where: { id: req.params.paymentId },
      data:  { status: 'confirmed', confirmedAt: new Date(), confirmedBy: req.admin.id },
    });

    // Remove manual suspension override if any
    await prisma.distributor.update({
      where: { code: payment.distributorCode },
      data:  { statusOverride: null },
    });

    await prisma.activityLog.create({
      data: { actorType: 'admin', actorId: req.admin.id, action: 'maintenance_confirmed', details: { paymentId: payment.id, distCode: payment.distributorCode } },
    });

    return res.json({ message: 'Maintenance payment confirmed. Account is now active.' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to confirm payment.' });
  }
});

// Reject a maintenance payment
router.post('/maintenance/:paymentId/reject', async (req, res) => {
  try {
    await prisma.maintenancePayment.update({
      where: { id: req.params.paymentId },
      data:  { status: 'rejected' },
    });
    return res.json({ message: 'Payment rejected.' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to reject payment.' });
  }
});

// ── PAYOUTS ───────────────────────────────────────────────────
router.get('/payouts', async (req, res) => {
  try {
    const payouts = await prisma.payoutRequest.findMany({
      include: { distributor: { select: { fname: true, lname: true, email: true, phone: true } } },
      orderBy: { requestedAt: 'desc' },
    });
    return res.json({ payouts });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load payouts.' });
  }
});

router.post('/payouts/:id/approve', async (req, res) => {
  try {
    const payout = await prisma.payoutRequest.update({
      where: { id: req.params.id },
      data:  { status: 'approved', processedAt: new Date() },
    });
    await prisma.activityLog.create({
      data: { actorType: 'admin', actorId: req.admin.id, action: 'payout_approved', details: { payoutId: payout.id, amount: payout.amount } },
    });
    return res.json({ message: 'Payout approved.' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to approve payout.' });
  }
});

router.post('/payouts/:id/reject', async (req, res) => {
  try {
    const { note } = req.body;
    await prisma.payoutRequest.update({
      where: { id: req.params.id },
      data:  { status: 'rejected', processedAt: new Date(), adminNote: note || null },
    });
    return res.json({ message: 'Payout rejected.' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to reject payout.' });
  }
});

// ── ORDERS ────────────────────────────────────────────────────
router.get('/orders', async (req, res) => {
  try {
    const orders = await prisma.order.findMany({
      orderBy: { createdAt: 'desc' },
      take:    500,
    });
    return res.json({ orders });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load orders.' });
  }
});

router.post('/orders/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ['pending','payment_confirmed','processing','shipped','delivered','cancelled'];
    if (!validStatuses.includes(status)) return res.status(400).json({ error: 'Invalid status.' });
    const order = await prisma.order.update({ where: { id: req.params.id }, data: { status } });
    return res.json({ order });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update order status.' });
  }
});

// ── SALES OVERVIEW ────────────────────────────────────────────
router.get('/overview', async (req, res) => {
  try {
    const [totalRevenue, totalUnits, distCount, orderCount, commTotal] = await Promise.all([
      prisma.sale.aggregate({ _sum: { revenue: true } }),
      prisma.sale.aggregate({ _sum: { quantity: true } }),
      prisma.distributor.count(),
      prisma.order.count(),
      prisma.commission.aggregate({ where: { status: { in: ['confirmed','paid'] } }, _sum: { commissionAmount: true } }),
    ]);

    return res.json({
      totalRevenue:       totalRevenue._sum.revenue || 0,
      totalUnits:         totalUnits._sum.quantity  || 0,
      distributorCount:   distCount,
      orderCount,
      commissionsPaid:    commTotal._sum.commissionAmount || 0,
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load overview.' });
  }
});

// ── COMMISSIONS — confirm pending ─────────────────────────────
router.post('/commissions/:id/confirm', async (req, res) => {
  try {
    await prisma.commission.update({ where: { id: req.params.id }, data: { status: 'confirmed' } });
    return res.json({ message: 'Commission confirmed.' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to confirm commission.' });
  }
});

// ── ACTIVITY LOG ──────────────────────────────────────────────
router.get('/activity', requireOwner, async (req, res) => {
  const logs = await prisma.activityLog.findMany({ orderBy: { createdAt: 'desc' }, take: 200 });
  return res.json({ logs });
});

// ── HELPERS ───────────────────────────────────────────────────
function safeDistributor(d) {
  const { passwordHash, idNumber, maintenancePayments, _count, ...safe } = d;
  return safe;
}

export default router;
