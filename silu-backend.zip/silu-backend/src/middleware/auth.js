// src/middleware/auth.js
import jwt from 'jsonwebtoken';
import prisma from '../lib/prisma.js';

/**
 * Verify distributor JWT — attaches req.distributor
 */
export async function requireDistributor(req, res, next) {
  try {
    const token = extractToken(req);
    if (!token) return res.status(401).json({ error: 'Authentication required.' });

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.type !== 'distributor') return res.status(403).json({ error: 'Distributor token required.' });

    const dist = await prisma.distributor.findUnique({
      where: { code: payload.code },
      select: { id: true, code: true, fname: true, lname: true, email: true, statusOverride: true, rankName: true },
    });
    if (!dist) return res.status(401).json({ error: 'Account not found.' });

    req.distributor = dist;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
}

/**
 * Verify admin JWT — attaches req.admin
 */
export async function requireAdmin(req, res, next) {
  try {
    const token = extractToken(req);
    if (!token) return res.status(401).json({ error: 'Admin authentication required.' });

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.type !== 'admin') return res.status(403).json({ error: 'Admin token required.' });

    const admin = await prisma.adminUser.findUnique({ where: { id: payload.id } });
    if (!admin) return res.status(401).json({ error: 'Admin account not found.' });

    req.admin = admin;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired admin token.' });
  }
}

/**
 * Owner-only — subset of admin
 */
export async function requireOwner(req, res, next) {
  await requireAdmin(req, res, () => {
    if (req.admin.role !== 'owner') {
      return res.status(403).json({ error: 'Owner access only.' });
    }
    next();
  });
}

function extractToken(req) {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) return auth.slice(7);
  return null;
}
